---
name: Warm Culinary AR
colors:
  surface: '#fff8f4'
  surface-dim: '#e0d9d3'
  surface-bright: '#fff8f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2ed'
  surface-container: '#f4ece7'
  surface-container-high: '#eee7e1'
  surface-container-highest: '#e9e1dc'
  on-surface: '#1e1b18'
  on-surface-variant: '#594139'
  inverse-surface: '#33302c'
  inverse-on-surface: '#f7efea'
  outline: '#8d7168'
  outline-variant: '#e1bfb5'
  surface-tint: '#ab3600'
  primary: '#a73400'
  on-primary: '#ffffff'
  primary-container: '#cb4914'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#006947'
  on-tertiary: '#ffffff'
  tertiary-container: '#00855b'
  on-tertiary-container: '#f5fff6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#822700'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#fff8f4'
  on-background: '#1e1b18'
  surface-variant: '#e9e1dc'
typography:
  display-hero:
    fontFamily: Epilogue
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Epilogue
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system crafts an inviting, sensory-rich digital hospitality experience bridging physical dining with interactive augmented reality. The aesthetic synthesizes the intimacy of third-wave artisanal coffee culture and fine dining with the high-tech precision of spatial food previews.

### Design Movement: Modern Warm Hospitality & Spatial Tactility
The visual philosophy pairs soft editorial warmth with spatial glassmorphism. Culinary photography and real-time 3D models take center stage against rich, creamy substrates. Interactive touchpoints balance tactile reassurance—such as deep terracotta interactive surfaces and golden-hour highlights—with translucent camera HUDs, floating AR rings, and smooth micro-interactions that make dining exploration feel effortless and delightful.

### Target Audience & Emotional Intent
- **Audience:** Culinary enthusiasts, experiential cafe-goers, and patrons seeking sensory clarity and dietary confidence through interactive visualization.
- **Emotional Response:** Comfort, sensory craving, modern sophistication, and playful curiosity when projecting culinary creations onto the table surface.

## Colors

The palette radiates culinary warmth, daylight dining, and botanical freshness, anchored by deep espresso grounds.

- **Primary (`#D9531E` - Terracotta Embers):** Drives dominant calls-to-action, primary pricing badges, dynamic cart triggers, and core interactive AR focal points. Conveys warmth and fireside culinary preparation.
- **Secondary (`#F59E0B` - Warm Golden Honey):** Highlights ratings, chef recommendations, seasonal alerts, and luminous spatial anchors.
- **Tertiary (`#10B981` - Fresh Sage / Herb Green):** Governs dietary certifications (vegan, organic, gluten-free), live prep statuses, and instant confirmation badges.
- **Neutral (`#1E1B18` - Dark Espresso):** High-contrast anchor for typography, structural borders, and dark navigation surfaces.
- **Canvas & Backgrounds:**
  - Base surface: `#FAF8F5` (Cream Linen)
  - Card/Raised surface: `#FFFFFF` (Pure White)
  - Muted backdrop: `#F2ECE4` (Oat Milk)
  - AR Dark Overlay: `rgba(30, 27, 24, 0.75)` with backdrop blur for spatial viewport camera interfaces.

## Typography

The type system blends editorial character with ergonomic functional readability.

- **Headlines (Epilogue):** An expressive geometric sans with editorial gravitas. It infuses menu category titles, signature dish names, and narrative tasting notes with a boutique restaurant identity.
- **Body & Labels (Plus Jakarta Sans):** A friendly, open grotesque optimized for extreme legibility in varied lighting conditions—from dim evening dining rooms to sunlit patio cafe tables.
- **Optical Adjustments:** High-level headers apply negative tracking to tighten display impact. Micro-labels and dietary badge tags feature positive tracking for effortless scanning across high-density menu grids and AR HUD overlays.

## Layout & Spacing

The layout is built upon an adaptive 12-column responsive grid designed to accommodate mobile-first table ordering alongside expanded desktop catering portals.

### Breakpoints & Reflow
- **Mobile (< 768px):** 4-column layout with `1rem` margins and `1rem` gutters. Menu feeds stack vertically; dish previews use full-width cards with swipeable ingredient tags. AR scanning viewports take complete screen real estate with floating control margins of `1rem`.
- **Tablet (768px – 1024px):** 8-column layout with `1.5rem` margins and gutters. Introduces split views: persistent category side-rail on the left with a 2-column food card matrix on the right.
- **Desktop (> 1024px):** 12-column layout with maximum content width capped at `1280px` centered. 3 to 4-column item grids, persistent order summary tray, and side-by-side AR 3D interactive viewer modals.

### Spacing Philosophy
Consistent vertical rhythm relies on an 8pt base grid (`0.5rem` base unit). Tight spacings (`0.25rem`–`0.5rem`) cluster dish titles with calorie and allergen badges. Broader spacings (`1.5rem`–`2.5rem`) separate distinct courses (e.g., Pour-Over Bar, Brunch Mains, Bakery).

## Elevation & Depth

Visual hierarchy uses warm, sun-cast ambient shadows and translucent frosted layers rather than cold, clinical drop shadows.

### Ambient Shadow Levels
- **Base Level (Cards, Inactive Trays):** `0 4px 16px -2px rgba(30, 27, 24, 0.05), 0 2px 6px -1px rgba(30, 27, 24, 0.03)` creates soft detachment from the `#FAF8F5` surface.
- **Raised Level (Hovered Dish Cards, Sticky Bottom Bars):** `0 12px 28px -4px rgba(30, 27, 24, 0.08), 0 4px 10px -2px rgba(30, 27, 24, 0.04)`.
- **Overlay Level (Modals, Nutrition Panels):** `0 24px 48px -8px rgba(30, 27, 24, 0.16)`.

### Spatial & AR Frosted Glass
For camera feeds and floating contextual controls:
- **Surface:** `rgba(250, 248, 245, 0.82)` with `backdrop-filter: blur(16px)` and an ultra-fine border `1px solid rgba(255, 255, 255, 0.6)`.
- **Dark HUD Surface (AR Mode):** `rgba(30, 27, 24, 0.65)` with `backdrop-filter: blur(20px)` and border `1px solid rgba(255, 255, 255, 0.15)` for ambient sensor overlays.

## Shapes

The design uses pill-shaped, fully rounded contours (`level 3`) to evoke organic tableware, smooth river stones, and ceramic coffee cups.

- **Pills & Micro-Badges:** Dietary chips, status pills, filter carousels, and action buttons use complete pill curvature (`9999px` / `rounded-full`).
- **Cards & Visual Containers:** Food cards, AR viewfinders, and modal dialogs adopt generous rounded boundaries (`2rem` desktop, `1.5rem` mobile), softening the digital interface and harmonizing with circular dining plates and glassware.
- **Interactive Targets:** Floating circular buttons (`width: 48px`, `height: 48px`, `border-radius: 50%`) serve as tactile tap targets for quick actions like AR re-centering and waiter paging.

## Components

### Buttons
- **Primary CTA:** Pill-shaped, background `#D9531E`, text `#FFFFFF`, font `label-lg`. Padding: `14px 28px`. Hover: translateY(-1px) with warmth-saturated glow (`box-shadow: 0 8px 20px -2px rgba(217, 83, 30, 0.35)`). Active: scale(0.98).
- **Secondary CTA:** Pill-shaped, transparent background, border: `1.5px solid #1E1B18`, text `#1E1B18`.
- **Ghost/Tertiary:** Minimalist padding, text `#D9531E`, transparent background.

### Food & Beverage Cards
- **Structure:** Vertical card on mobile, grid-aligned on desktop. Top-anchored 4:3 high-res imagery with inset AR trigger icon pill in the upper-right corner ("View in 360° / AR").
- **Content:** Headline-sm title, one-line sensory tasting note, price in bold Espresso (`#1E1B18`), and an instant pill add button.

### Dietary & Filter Chips
- Height: `32px`. Pill-shaped border-radius (`9999px`).
- **Unselected:** Background `#FFFFFF`, border `1px solid #E6E0D8`, text `#1E1B18`.
- **Selected:** Background `#1E1B18`, text `#FAF8F5`, border `1px solid #1E1B18`.
- **Status Pills (e.g., Vegan, Gluten-Free):** Soft background `#10B981` at 12% opacity with text `#047857` and small leading icon.

### Form Inputs & Adjusters
- **Quantity Selectors:** Pill capsule enclosing `[-] count [+]` with crisp tactile feedback and subtle espresso divider lines.
- **Special Instruction Fields:** Background `#FFFFFF`, border `1.5px solid #E6E0D8`, radius `1rem`, focus state border `#D9531E` with zero harsh outline.

### AR Visualizer Elements
- **Plane Indicator:** Pulsing concentric golden honey rings (`#F59E0B` with animated stroke dash-array) indicating real-world table surface detection.
- **Bounding Box / Dimensions:** Slender semi-transparent white corner guides with floating pill dimension tags (e.g., "18cm plate footprint").
- **AR Action Dock:** Floating bottom pill container (`backdrop-filter: blur(20px)`) holding scale adjustment sliders (100% true-to-scale lock), calorie details, and a primary "Add to Table Order" button.

### Floating Hospitality Anchors
- **Call Waiter / Service Button:** Floating round button anchored bottom-right. Espresso base (`#1E1B18`), illuminated golden honey icon (`#F59E0B`), elevated with `elevation-raised`. Expands on press to display "Water", "Bill", or "Assistance".